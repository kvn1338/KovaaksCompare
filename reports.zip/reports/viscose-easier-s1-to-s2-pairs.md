# Viscose Easier Calibration

Mapping: Viscose Easier -> Viscose Benchmark S2 Easier

Source benchmark: Viscose Easier
Target benchmark: Viscose Benchmark S2 Easier

## WhisphereRawControl Larger + Slowed -> Smoothsphere Viscose Easier

Source leaderboard: 128696
Target leaderboard: 185342
Overlapping players: 1764 (2.7%)
Correlation: 0.8332
Log correlation: 0.8187
Linear regression: target ~= 0.7649 * source + 3786.44 (R^2 0.6942)
Trimmed regression: target ~= 0.7783 * source + 3669.73 (R^2 0.7689, n=1676)
Log-log regression: log(target) ~= 0.6409 * log(source) + 3.4484 (R^2 0.6703, n=1764)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 12234 | 50% | 12858 | high |
| 12612 | 60% | 13329 | high |
| 12999 | 75% | 14160 | high |
| 13827 | 88% | 15084 | high |
| 15012 | 95% | 15891 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 5500 | 12.7% | 10026 | 8883 | 9876 | 7993 | 7951 | 7849 | high |
| 6700 | 22.2% | 11097 | 9540 | 9876 | 8911 | 8885 | 8907 | high |
| 7800 | 32.7% | 11760 | 9879 | 10187 | 9753 | 9741 | 9818 | high |
| 8700 | 42.1% | 12327 | 10887 | 10908 | 10441 | 10441 | 10530 | high |
| 9600 | 52.6% | 12876 | 11139 | 11208 | 11129 | 11142 | 11216 | high |
| 10500 | 63.2% | 13455 | 11763 | 11740 | 11818 | 11842 | 11879 | high |
| 11400 | 74.4% | 14064 | 12336 | 12376 | 12506 | 12543 | 12522 | high |
| 12500 | 84.5% | 14775 | 13617 | 13590 | 13347 | 13399 | 13283 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Whisphere 80% -> VT Controlsphere Viscose Easier

Source leaderboard: 55382
Target leaderboard: 184157
Overlapping players: 1605 (2.5%)
Correlation: 0.8801
Log correlation: 0.8785
Linear regression: target ~= 0.2390 * source + 356.35 (R^2 0.7745)
Trimmed regression: target ~= 0.2409 * source + 334.36 (R^2 0.8295, n=1525)
Log-log regression: log(target) ~= 0.9024 * log(source) + -0.4023 (R^2 0.7718, n=1605)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 14750 | 50% | 3854 | high |
| 15080 | 60% | 4044 | high |
| 16100 | 75% | 4358 | high |
| 17680 | 88% | 4712 | high |
| 19220 | 95% | 5016 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 6300 | 7.3% | 2376 | 2256 | 2559 | 1862 | 1852 | 1795 | high |
| 7700 | 15.5% | 2846 | 2363 | 2559 | 2196 | 2190 | 2151 | high |
| 9000 | 25.8% | 3206 | 2490 | 2559 | 2507 | 2503 | 2476 | high |
| 10000 | 35.0% | 3449 | 2732 | 2759 | 2746 | 2744 | 2723 | high |
| 11000 | 44.9% | 3690 | 2949 | 2965 | 2985 | 2985 | 2968 | high |
| 12000 | 55.6% | 3902 | 3276 | 3161 | 3224 | 3226 | 3210 | high |
| 13000 | 66.5% | 4130 | 3427 | 3423 | 3463 | 3467 | 3451 | high |
| 14500 | 79.2% | 4423 | 3793 | 3784 | 3822 | 3828 | 3808 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## SmoothBot Invincible Goated 75% -> SmoothBot Perfected Easier

Source leaderboard: 75962
Target leaderboard: 184652
Overlapping players: 1560 (2.7%)
Correlation: 0.8589
Log correlation: 0.8422
Linear regression: target ~= 1.0827 * source + 806.78 (R^2 0.7378)
Trimmed regression: target ~= 1.1162 * source + 694.93 (R^2 0.8068, n=1482)
Log-log regression: log(target) ~= 0.7776 * log(source) + 2.0873 (R^2 0.7094, n=1560)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 3708 | 50% | 4786 | high |
| 3906 | 60% | 4983 | high |
| 4056 | 75% | 5263 | high |
| 4182 | 88% | 5573 | high |
| 4410 | 95% | 5854 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 1800 | 8.4% | 3354 | 3250 | 3602 | 2756 | 2704 | 2740 | high |
| 2250 | 21.2% | 3958 | 3380 | 3602 | 3243 | 3206 | 3259 | high |
| 2650 | 36.9% | 4405 | 3774 | 3795 | 3676 | 3653 | 3701 | high |
| 2900 | 48.0% | 4679 | 3900 | 3977 | 3947 | 3932 | 3970 | high |
| 3150 | 59.7% | 4930 | 4216 | 4127 | 4217 | 4211 | 4233 | high |
| 3400 | 70.5% | 5129 | 4520 | 4505 | 4488 | 4490 | 4492 | high |
| 3650 | 81.2% | 5373 | 4751 | 4711 | 4759 | 4769 | 4747 | high |
| 4000 | 90.1% | 5631 | 5276 | 5284 | 5138 | 5160 | 5097 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Leaptrack Goated 60% Larger -> Leapstrafes Control wobin Easier

Source leaderboard: 128691
Target leaderboard: 185344
Overlapping players: 1375 (2.4%)
Correlation: 0.8203
Log correlation: 0.8190
Linear regression: target ~= 1.6176 * source + -811.45 (R^2 0.6729)
Trimmed regression: target ~= 1.6528 * source + -899.40 (R^2 0.7470, n=1307)
Log-log regression: log(target) ~= 1.2251 * log(source) + -1.5137 (R^2 0.6707, n=1375)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 2534 | 50% | 3262 | high |
| 2592 | 60% | 3448 | high |
| 2707 | 75% | 3685 | high |
| 2867 | 88% | 4059 | high |
| 3046 | 95% | 4351 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 850 | 0.4% | 1251 | 2075 | 2325 | 564 | 505 | 854 | high |
| 1200 | 2.0% | 1652 | 2075 | 2325 | 1130 | 1084 | 1302 | high |
| 1500 | 6.5% | 2085 | 2075 | 2325 | 1615 | 1580 | 1712 | high |
| 1700 | 12.7% | 2364 | 2183 | 2325 | 1939 | 1910 | 1996 | high |
| 1900 | 22.4% | 2685 | 2325 | 2340 | 2262 | 2241 | 2287 | high |
| 2100 | 36.3% | 2942 | 2671 | 2671 | 2586 | 2572 | 2585 | high |
| 2250 | 50.0% | 3213 | 2782 | 2774 | 2828 | 2819 | 2813 | high |
| 2450 | 68.0% | 3539 | 3139 | 3070 | 3152 | 3150 | 3122 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Controlsphere rAim Easy 90% -> Controlsphere SuperbAim Viscose Easier

Source leaderboard: 83485
Target leaderboard: 185345
Overlapping players: 1306 (2.3%)
Correlation: 0.8870
Log correlation: 0.8876
Linear regression: target ~= 1.0054 * source + -197.34 (R^2 0.7868)
Trimmed regression: target ~= 1.0248 * source + -421.38 (R^2 0.8437, n=1241)
Log-log regression: log(target) ~= 1.0025 * log(source) + -0.0408 (R^2 0.7879, n=1306)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 11586 | 50% | 11271 | high |
| 11799 | 60% | 11781 | high |
| 12258 | 75% | 12657 | high |
| 13281 | 88% | 13710 | high |
| 14277 | 95% | 14493 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 6100 | 13.1% | 7881 | 6699 | 7725 | 5936 | 5830 | 5984 | high |
| 6950 | 20.8% | 8889 | 7082 | 7725 | 6790 | 6701 | 6820 | high |
| 7700 | 28.9% | 9558 | 7725 | 7865 | 7544 | 7469 | 7558 | high |
| 8400 | 37.5% | 10257 | 8364 | 8310 | 8248 | 8187 | 8246 | high |
| 9100 | 47.1% | 10938 | 8606 | 8876 | 8952 | 8904 | 8935 | high |
| 9800 | 57.4% | 11505 | 9621 | 9577 | 9655 | 9621 | 9624 | high |
| 10500 | 68.5% | 12132 | 10092 | 10135 | 10359 | 10339 | 10314 | high |
| 11500 | 80.3% | 12918 | 11522 | 11460 | 11365 | 11364 | 11298 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## VT Controlsphere Intermediate S5 80% -> Whisphere Viscose Easier

Source leaderboard: 107281
Target leaderboard: 185346
Overlapping players: 1214 (2.2%)
Correlation: 0.8523
Log correlation: 0.8444
Linear regression: target ~= 4.8643 * source + -1682.38 (R^2 0.7263)
Trimmed regression: target ~= 5.0221 * source + -2265.90 (R^2 0.7940, n=1154)
Log-log regression: log(target) ~= 1.0191 * log(source) + 1.3220 (R^2 0.7131, n=1214)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 4112 | 50% | 17740 | high |
| 4178 | 60% | 18710 | high |
| 4316 | 75% | 20270 | high |
| 4580 | 88% | 22000 | high |
| 4891 | 95% | 23520 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 1850 | 6.4% | 10420 | 10550 | 11660 | 7316 | 7025 | 8013 | high |
| 2300 | 15.4% | 12700 | 10940 | 11660 | 9505 | 9285 | 10004 | high |
| 2700 | 26.8% | 14500 | 11660 | 12100 | 11451 | 11294 | 11780 | high |
| 3000 | 37.1% | 15710 | 13220 | 13357 | 12910 | 12800 | 13115 | high |
| 3300 | 49.3% | 17280 | 13760 | 13859 | 14370 | 14307 | 14453 | high |
| 3600 | 61.8% | 18672 | 14940 | 14940 | 15829 | 15814 | 15793 | high |
| 3850 | 72.9% | 19780 | 16590 | 16150 | 17045 | 17069 | 16912 | high |
| 4100 | 81.5% | 20900 | 18910 | 18610 | 18261 | 18325 | 18031 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Air Angelic 4 Voltaic Easy 80% (Good Version) -> Air Angelic 4 Voltaic Easy 70%

Source leaderboard: 13681
Target leaderboard: 14155
Overlapping players: 246 (12.3%)
Correlation: 0.4942
Log correlation: 0.4746
Linear regression: target ~= 0.7853 * source + 2177.10 (R^2 0.2442)
Trimmed regression: target ~= 0.7305 * source + 2438.53 (R^2 0.3902, n=234)
Log-log regression: log(target) ~= 0.6092 * log(source) + 3.5255 (R^2 0.2252, n=246)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 4145 | 50% | 5487 | medium |
| 4182 | 60% | 5524 | medium |
| 4277 | 75% | 5593 | medium |
| 4363 | 88% | 5678 | medium |
| 4440 | 95% | 5745 | medium |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 1050 | 0.0% | 705 | 5343 | 5434 | 3002 | 3206 | 2352 | medium |
| 1600 | 0.0% | 705 | 5343 | 5434 | 3434 | 3607 | 3040 | medium |
| 2000 | 0.0% | 705 | 5343 | 5434 | 3748 | 3900 | 3483 | medium |
| 2400 | 0.0% | 705 | 5343 | 5434 | 4062 | 4192 | 3892 | medium |
| 2700 | 0.0% | 705 | 5343 | 5434 | 4297 | 4411 | 4181 | medium |
| 3000 | 0.0% | 705 | 5343 | 5434 | 4533 | 4630 | 4458 | medium |
| 3300 | 0.0% | 705 | 5343 | 5434 | 4769 | 4849 | 4725 | medium |
| 3600 | 0.0% | 705 | 5343 | 5434 | 5004 | 5068 | 4982 | medium |

### Warnings

- Source leaderboard collection is partial: 2000/73973 scores stored.
- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## cloverRawControl Easy 80% Speed -> cloverRawControl Viscose Easier 50cm

Source leaderboard: 98867
Target leaderboard: 185349
Overlapping players: 1109 (2.0%)
Correlation: 0.8480
Log correlation: 0.8459
Linear regression: target ~= 1.2110 * source + 1571.84 (R^2 0.7192)
Trimmed regression: target ~= 1.2289 * source + 1430.63 (R^2 0.7966, n=1054)
Log-log regression: log(target) ~= 0.8539 * log(source) + 1.6501 (R^2 0.7155, n=1109)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 7845 | 50% | 11079 | high |
| 8091 | 60% | 11742 | high |
| 8556 | 75% | 12579 | high |
| 9306 | 88% | 13539 | high |
| 10437 | 95% | 14340 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 3900 | 13.1% | 7716 | 6732 | 7326 | 6295 | 6223 | 6070 | high |
| 4550 | 21.7% | 8685 | 7053 | 7326 | 7082 | 7022 | 6924 | high |
| 5200 | 31.2% | 9717 | 7478 | 7657 | 7869 | 7821 | 7760 | high |
| 5700 | 39.6% | 10311 | 8381 | 8223 | 8475 | 8435 | 8393 | high |
| 6200 | 48.7% | 10800 | 8696 | 8766 | 9080 | 9050 | 9017 | high |
| 6700 | 58.2% | 11415 | 9300 | 9418 | 9686 | 9664 | 9635 | high |
| 7200 | 68.6% | 12087 | 10385 | 10194 | 10291 | 10279 | 10246 | high |
| 7700 | 76.9% | 12597 | 11171 | 10955 | 10897 | 10893 | 10850 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Controlsphere Far, Far Larger 90% -> Flower Easier 50cm

Source leaderboard: 128692
Target leaderboard: 185354
Overlapping players: 1044 (2.0%)
Correlation: 0.7698
Log correlation: 0.7628
Linear regression: target ~= 0.3830 * source + -1247.61 (R^2 0.5925)
Trimmed regression: target ~= 0.3997 * source + -1424.39 (R^2 0.6747, n=992)
Log-log regression: log(target) ~= 1.3102 * log(source) + -4.2230 (R^2 0.5819, n=1044)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 11541 | 50% | 2974 | high |
| 11652 | 60% | 3176 | high |
| 11946 | 75% | 3533 | high |
| 12468 | 88% | 3970 | high |
| 13077 | 95% | 4351 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 7600 | 22.6% | 2249 | 1774 | 1774 | 1663 | 1613 | 1781 | high |
| 8150 | 29.5% | 2407 | 1775 | 1922 | 1874 | 1833 | 1951 | high |
| 8700 | 37.0% | 2593 | 2219 | 2131 | 2084 | 2053 | 2126 | high |
| 9200 | 44.3% | 2765 | 2097 | 2194 | 2276 | 2253 | 2287 | high |
| 9800 | 54.0% | 3011 | 2234 | 2236 | 2506 | 2492 | 2484 | high |
| 10200 | 61.2% | 3158 | 2426 | 2406 | 2659 | 2652 | 2618 | high |
| 10900 | 74.1% | 3492 | 2683 | 2761 | 2927 | 2932 | 2856 | high |
| 11500 | 82.0% | 3732 | 3259 | 3204 | 3157 | 3172 | 3064 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## PGTI Voltaic Easy 80% -> PGTI Voltaic Easy Smoother

Source leaderboard: 2107
Target leaderboard: 184878
Overlapping players: 967 (2.0%)
Correlation: 0.8979
Log correlation: 0.8992
Linear regression: target ~= 1.1361 * source + 62.22 (R^2 0.8061)
Trimmed regression: target ~= 1.1430 * source + 50.51 (R^2 0.8601, n=919)
Log-log regression: log(target) ~= 0.9454 * log(source) + 0.5607 (R^2 0.8085, n=967)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 2048 | 50% | 2298 | high |
| 2258 | 60% | 2468 | high |
| 2360 | 75% | 2800 | high |
| 2493 | 88% | 3135 | high |
| 2877 | 95% | 3487 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 350 | 1.1% | 566 | 1039 | 1177 | 460 | 451 | 445 | high |
| 550 | 5.0% | 977 | 1039 | 1177 | 687 | 679 | 683 | high |
| 850 | 16.9% | 1498 | 1099 | 1177 | 1028 | 1022 | 1030 | high |
| 1100 | 31.4% | 1847 | 1322 | 1318 | 1312 | 1308 | 1314 | high |
| 1350 | 47.6% | 2183 | 1595 | 1556 | 1596 | 1594 | 1595 | high |
| 1600 | 62.3% | 2468 | 1835 | 1827 | 1880 | 1879 | 1873 | high |
| 1900 | 78.1% | 2836 | 2201 | 2174 | 2221 | 2222 | 2203 | high |
| 2250 | 88.3% | 3125 | 2542 | 2539 | 2618 | 2622 | 2585 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Air CELESTIAL No UFO Easy Slowed -> Air CELESTIAL No UFO Easier

Source leaderboard: 131872
Target leaderboard: 185640
Overlapping players: 906 (2.0%)
Correlation: 0.8657
Log correlation: 0.8615
Linear regression: target ~= 1.2012 * source + -184.19 (R^2 0.7495)
Trimmed regression: target ~= 1.1726 * source + -157.78 (R^2 0.8411, n=861)
Log-log regression: log(target) ~= 1.2135 * log(source) + -1.4561 (R^2 0.7421, n=906)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 894.04 | 50% | 893 | high |
| 896.31 | 60% | 896 | high |
| 902.13 | 75% | 903 | high |
| 907.63 | 88% | 908 | high |
| 912.95 | 95% | 913 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 820 | 5.1% | 837 | 838 | 854 | 801 | 804 | 801 | high |
| 835 | 8.6% | 850 | 841 | 854 | 819 | 821 | 819 | high |
| 850 | 15.2% | 862 | 844 | 854 | 837 | 839 | 837 | high |
| 861 | 22.9% | 871 | 853 | 854 | 850 | 852 | 850 | high |
| 870 | 32.8% | 880 | 858 | 858 | 861 | 862 | 861 | high |
| 878 | 44.7% | 888 | 873 | 872 | 870 | 872 | 870 | high |
| 884 | 56.1% | 894 | 876 | 878 | 878 | 879 | 878 | high |
| 890 | 67.8% | 898 | 883 | 888 | 885 | 886 | 885 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Whisphere Small & Slow 55% -> RawControlSphere Easier

Source leaderboard: 128693
Target leaderboard: 185356
Overlapping players: 935 (1.9%)
Correlation: 0.8491
Log correlation: 0.8539
Linear regression: target ~= 1.3175 * source + -5482.62 (R^2 0.7209)
Trimmed regression: target ~= 1.3507 * source + -5879.59 (R^2 0.7888, n=889)
Log-log regression: log(target) ~= 1.5034 * log(source) + -4.8909 (R^2 0.7292, n=935)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 13610 | 50% | 12162 | high |
| 13780 | 60% | 12795 | high |
| 14140 | 75% | 13545 | high |
| 14650 | 88% | 14502 | high |
| 15270 | 95% | 15492 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 6000 | 1.2% | 4857 | 7290 | 8163 | 2423 | 2225 | 3597 | high |
| 7500 | 4.2% | 6585 | 7290 | 8163 | 4399 | 4251 | 5031 | high |
| 9000 | 11.6% | 8355 | 7413 | 8163 | 6375 | 6277 | 6618 | high |
| 10000 | 20.9% | 9558 | 7902 | 8163 | 7693 | 7628 | 7754 | high |
| 10750 | 30.5% | 10533 | 8631 | 8607 | 8681 | 8641 | 8644 | high |
| 11500 | 42.5% | 11499 | 9591 | 9615 | 9669 | 9654 | 9567 | high |
| 12250 | 57.3% | 12471 | 10743 | 10576 | 10657 | 10667 | 10520 | high |
| 13500 | 78.5% | 13731 | 12618 | 12507 | 12304 | 12355 | 12175 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Air Voltaic Invincible 7 Easy 80% -> Ground Plaza Sparky v3 Easy

Source leaderboard: 128694
Target leaderboard: 134502
Overlapping players: 1196 (2.5%)
Correlation: 0.8160
Log correlation: n/a
Linear regression: target ~= 0.0403 * source + 761.02 (R^2 0.6659)
Trimmed regression: target ~= 0.0385 * source + 767.35 (R^2 0.7597, n=1137)
Log-log regression: log(target) ~= 0.1364 * log(source) + 5.6910 (R^2 0.7155, n=1195)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 3156 | 50% | 888 | high |
| 3225 | 60% | 892 | high |
| 3301 | 75% | 899 | high |
| 3457 | 88% | 904 | high |
| 3614 | 95% | 908 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 750 | 0.1% | 719 | 835 | 853 | 791 | 796 | 731 | high |
| 1200 | 0.5% | 759 | 835 | 853 | 809 | 814 | 779 | high |
| 1600 | 2.7% | 810 | 835 | 853 | 826 | 829 | 810 | high |
| 1900 | 8.1% | 842 | 842 | 853 | 838 | 841 | 830 | high |
| 2200 | 20.4% | 865 | 852 | 853 | 850 | 852 | 846 | high |
| 2500 | 40.3% | 881 | 862 | 861 | 862 | 864 | 861 | high |
| 2800 | 64.9% | 894 | 878 | 877 | 874 | 875 | 875 | high |
| 3200 | 86.5% | 903 | 892 | 892 | 890 | 891 | 891 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Controlsphere OW Long Strafes 90% -> Air Spectral Easy 85%

Source leaderboard: 128697
Target leaderboard: 185693
Overlapping players: 779 (1.7%)
Correlation: 0.7192
Log correlation: 0.7209
Linear regression: target ~= 0.0055 * source + 879.90 (R^2 0.5173)
Trimmed regression: target ~= 0.0047 * source + 887.36 (R^2 0.6020, n=741)
Log-log regression: log(target) ~= 0.0460 * log(source) + 6.4153 (R^2 0.5197, n=779)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 8871 | 50% | 930 | high |
| 9051 | 60% | 932 | high |
| 9381 | 75% | 934 | high |
| 9936 | 88% | 936 | high |
| 10761 | 95% | 939 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 5400 | 15.6% | 917 | 915 | 917 | 909 | 913 | 908 | medium |
| 6100 | 23.9% | 922 | 917 | 917 | 913 | 916 | 913 | medium |
| 6700 | 32.5% | 925 | 919 | 917 | 916 | 919 | 917 | medium |
| 7200 | 40.8% | 927 | 919 | 919 | 919 | 921 | 920 | medium |
| 7600 | 48.8% | 929 | 921 | 921 | 921 | 923 | 922 | medium |
| 8000 | 57.7% | 931 | 923 | 924 | 924 | 925 | 924 | medium |
| 8300 | 65.8% | 932 | 924 | 927 | 925 | 926 | 926 | medium |
| 8700 | 74.7% | 934 | 929 | 930 | 927 | 928 | 928 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Flicker Plaza rAim Easy Less Blinks -> Air Spectral Easy 85%

Source leaderboard: 128774
Target leaderboard: 185693
Overlapping players: 781 (1.8%)
Correlation: 0.7504
Log correlation: 0.7494
Linear regression: target ~= 0.7896 * source + 206.60 (R^2 0.5632)
Trimmed regression: target ~= 0.7286 * source + 263.09 (R^2 0.6573, n=742)
Log-log regression: log(target) ~= 0.7783 * log(source) + 1.5272 (R^2 0.5617, n=781)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 913.78 | 50% | 930 | high |
| 915.72 | 60% | 932 | high |
| 918.83 | 75% | 934 | high |
| 922.72 | 88% | 937 | high |
| 926.03 | 95% | 939 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 858 | 1.3% | 884 | 912 | 918 | 884 | 888 | 884 | high |
| 871 | 3.1% | 897 | 912 | 918 | 894 | 898 | 894 | high |
| 883 | 7.3% | 911 | 915 | 918 | 904 | 906 | 904 | high |
| 890 | 12.3% | 916 | 916 | 918 | 909 | 912 | 909 | high |
| 895 | 18.4% | 919 | 917 | 918 | 913 | 915 | 913 | high |
| 900 | 27.6% | 923 | 920 | 920 | 917 | 919 | 917 | high |
| 904 | 37.8% | 927 | 922 | 922 | 920 | 922 | 920 | high |
| 909 | 53.3% | 930 | 928 | 927 | 924 | 925 | 924 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Controlsphere OW Long Strafes 90% -> Air Spectral Easy 85%

Source leaderboard: 128697
Target leaderboard: 185693
Overlapping players: 779 (1.7%)
Correlation: 0.7192
Log correlation: 0.7209
Linear regression: target ~= 0.0055 * source + 879.90 (R^2 0.5173)
Trimmed regression: target ~= 0.0047 * source + 887.36 (R^2 0.6020, n=741)
Log-log regression: log(target) ~= 0.0460 * log(source) + 6.4153 (R^2 0.5197, n=779)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 8871 | 50% | 930 | high |
| 9051 | 60% | 932 | high |
| 9381 | 75% | 934 | high |
| 9936 | 88% | 936 | high |
| 10761 | 95% | 939 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 5400 | 15.6% | 917 | 915 | 917 | 909 | 913 | 908 | medium |
| 6100 | 23.9% | 922 | 917 | 917 | 913 | 916 | 913 | medium |
| 6700 | 32.5% | 925 | 919 | 917 | 916 | 919 | 917 | medium |
| 7200 | 40.8% | 927 | 919 | 919 | 919 | 921 | 920 | medium |
| 7600 | 48.8% | 929 | 921 | 921 | 921 | 923 | 922 | medium |
| 8000 | 57.7% | 931 | 923 | 924 | 924 | 925 | 924 | medium |
| 8300 | 65.8% | 932 | 924 | 927 | 925 | 926 | 926 | medium |
| 8700 | 74.7% | 934 | 929 | 930 | 927 | 928 | 928 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Controlsphere OW Long Strafes 90% -> Air Spectral Easy 85%

Source leaderboard: 128697
Target leaderboard: 185693
Overlapping players: 779 (1.7%)
Correlation: 0.7192
Log correlation: 0.7209
Linear regression: target ~= 0.0055 * source + 879.90 (R^2 0.5173)
Trimmed regression: target ~= 0.0047 * source + 887.36 (R^2 0.6020, n=741)
Log-log regression: log(target) ~= 0.0460 * log(source) + 6.4153 (R^2 0.5197, n=779)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 8871 | 50% | 930 | high |
| 9051 | 60% | 932 | high |
| 9381 | 75% | 934 | high |
| 9936 | 88% | 936 | high |
| 10761 | 95% | 939 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 5400 | 15.6% | 917 | 915 | 917 | 909 | 913 | 908 | medium |
| 6100 | 23.9% | 922 | 917 | 917 | 913 | 916 | 913 | medium |
| 6700 | 32.5% | 925 | 919 | 917 | 916 | 919 | 917 | medium |
| 7200 | 40.8% | 927 | 919 | 919 | 919 | 921 | 920 | medium |
| 7600 | 48.8% | 929 | 921 | 921 | 921 | 923 | 922 | medium |
| 8000 | 57.7% | 931 | 923 | 924 | 924 | 925 | 924 | medium |
| 8300 | 65.8% | 932 | 924 | 927 | 925 | 926 | 926 | medium |
| 8700 | 74.7% | 934 | 929 | 930 | 927 | 928 | 928 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Controlsphere OW Long Strafes 90% -> Air Spectral Easy 85%

Source leaderboard: 128697
Target leaderboard: 185693
Overlapping players: 779 (1.7%)
Correlation: 0.7192
Log correlation: 0.7209
Linear regression: target ~= 0.0055 * source + 879.90 (R^2 0.5173)
Trimmed regression: target ~= 0.0047 * source + 887.36 (R^2 0.6020, n=741)
Log-log regression: log(target) ~= 0.0460 * log(source) + 6.4153 (R^2 0.5197, n=779)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 8871 | 50% | 930 | high |
| 9051 | 60% | 932 | high |
| 9381 | 75% | 934 | high |
| 9936 | 88% | 936 | high |
| 10761 | 95% | 939 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 5400 | 15.6% | 917 | 915 | 917 | 909 | 913 | 908 | medium |
| 6100 | 23.9% | 922 | 917 | 917 | 913 | 916 | 913 | medium |
| 6700 | 32.5% | 925 | 919 | 917 | 916 | 919 | 917 | medium |
| 7200 | 40.8% | 927 | 919 | 919 | 919 | 921 | 920 | medium |
| 7600 | 48.8% | 929 | 921 | 921 | 921 | 923 | 922 | medium |
| 8000 | 57.7% | 931 | 923 | 924 | 924 | 925 | 924 | medium |
| 8300 | 65.8% | 932 | 924 | 927 | 925 | 926 | 926 | medium |
| 8700 | 74.7% | 934 | 929 | 930 | 927 | 928 | 928 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Pokeball Frenzy Auto TE Wide -> VT Aether Novice S5 Bot 1

Source leaderboard: 783
Target leaderboard: 108042
Overlapping players: 143 (7.5%)
Correlation: 0.4043
Log correlation: 0.3984
Linear regression: target ~= 1.2264 * source + -875.21 (R^2 0.1634)
Trimmed regression: target ~= 1.1971 * source + -753.79 (R^2 0.2105, n=136)
Log-log regression: log(target) ~= 1.2969 * log(source) + -2.4587 (R^2 0.1588, n=143)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 3780 | 50% | 3790 | medium |
| 3810 | 60% | 3912 | medium |
| 3900 | 75% | 4101 | medium |
| 3990 | 88% | 4284 | medium |
| 4110 | 95% | 4569 | medium |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 650 | 0.0% | 0 | 3651 | 3651 | -78 | 24 | 380 | medium |
| 950 | 0.0% | 0 | 3651 | 3651 | 290 | 383 | 622 | medium |
| 1250 | 0.0% | 0 | 3651 | 3651 | 658 | 743 | 888 | medium |
| 1500 | 0.0% | 0 | 3651 | 3651 | 964 | 1042 | 1125 | medium |
| 1750 | 0.0% | 0 | 3651 | 3651 | 1271 | 1341 | 1374 | medium |
| 2000 | 0.0% | 0 | 3651 | 3651 | 1578 | 1641 | 1634 | medium |
| 2300 | 0.0% | 0 | 3651 | 3651 | 1946 | 2000 | 1959 | medium |
| 2700 | 0.0% | 0 | 3651 | 3651 | 2436 | 2479 | 2411 | medium |

### Warnings

- Source leaderboard collection is partial: 1900/72096 scores stored.
- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## 1w3ts reload Larger -> Plink Palace Easy Less Blinks

Source leaderboard: 128795
Target leaderboard: 184534
Overlapping players: 719 (1.6%)
Correlation: 0.6873
Log correlation: 0.6884
Linear regression: target ~= 23.4304 * source + 498.57 (R^2 0.4723)
Trimmed regression: target ~= 24.1631 * source + 431.05 (R^2 0.5701, n=684)
Log-log regression: log(target) ~= 0.8742 * log(source) + 3.9184 (R^2 0.4739, n=719)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 103 | 50% | 2944 | high |
| 105 | 60% | 3062 | high |
| 109 | 75% | 3246 | high |
| 117 | 88% | 3419 | high |
| 128 | 95% | 3602 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 36 | 0.1% | 781 | 2089 | 2234 | 1342 | 1301 | 1154 | medium |
| 50 | 0.4% | 1144 | 2089 | 2234 | 1670 | 1639 | 1538 | medium |
| 54 | 0.6% | 1267 | 2089 | 2234 | 1764 | 1736 | 1645 | medium |
| 58 | 1.2% | 1467 | 2089 | 2234 | 1858 | 1833 | 1751 | medium |
| 70 | 6.7% | 2027 | 2089 | 2234 | 2139 | 2122 | 2064 | medium |
| 82 | 24.4% | 2527 | 2409 | 2383 | 2420 | 2412 | 2370 | medium |
| 92 | 49.0% | 2913 | 2687 | 2687 | 2654 | 2654 | 2621 | medium |
| 102 | 73.3% | 3224 | 3003 | 3049 | 2888 | 2896 | 2869 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## voxTargetSwitch 2 Large -> ww5t Voltaic Slightly Larger

Source leaderboard: 84880
Target leaderboard: 185378
Overlapping players: 937 (2.0%)
Correlation: 0.8268
Log correlation: 0.8191
Linear regression: target ~= 1.0473 * source + -2.00 (R^2 0.6836)
Trimmed regression: target ~= 1.0605 * source + -3.95 (R^2 0.7627, n=891)
Log-log regression: log(target) ~= 0.9430 * log(source) + 0.2958 (R^2 0.6709, n=937)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 118 | 50% | 118 | high |
| 122.45 | 60% | 124 | high |
| 125 | 75% | 131 | high |
| 130.55 | 88% | 142 | high |
| 137.55 | 95% | 153 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 67 | 1.6% | 78 | 87 | 93 | 68 | 67 | 71 | high |
| 78 | 6.9% | 91 | 90 | 93 | 80 | 79 | 82 | high |
| 87 | 16.1% | 100 | 94 | 94 | 89 | 88 | 91 | high |
| 95 | 28.5% | 108 | 97 | 98 | 97 | 97 | 99 | high |
| 103 | 45.4% | 116 | 106 | 105 | 106 | 105 | 106 | high |
| 110 | 62.0% | 125 | 111 | 110 | 113 | 113 | 113 | high |
| 117 | 77.7% | 133 | 114 | 116 | 121 | 120 | 120 | high |
| 123 | 87.8% | 142 | 125 | 126 | 127 | 126 | 126 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## beanTS Larger -> 1w6ts reload v2 20% bigger

Source leaderboard: 129353
Target leaderboard: 21620
Overlapping players: 857 (1.8%)
Correlation: 0.7788
Log correlation: n/a
Linear regression: target ~= 0.7880 * source + 6.00 (R^2 0.6065)
Trimmed regression: target ~= 0.7833 * source + 6.26 (R^2 0.7242, n=815)
Log-log regression: log(target) ~= 0.8672 * log(source) + 0.4619 (R^2 0.6209, n=856)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 132.39 | 50% | 108 | high |
| 139 | 60% | 112 | high |
| 143 | 75% | 120 | high |
| 148.80 | 88% | 130 | high |
| 155 | 95% | 141 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 65 | 0.7% | 63 | 79 | 85 | 57 | 57 | 59 | high |
| 78 | 3.7% | 78 | 80 | 85 | 67 | 67 | 69 | high |
| 90 | 11.3% | 87 | 84 | 85 | 77 | 77 | 79 | high |
| 100 | 22.2% | 95 | 86 | 87 | 85 | 85 | 86 | high |
| 110 | 38.4% | 103 | 92 | 92 | 93 | 92 | 94 | high |
| 120 | 57.0% | 111 | 95 | 97 | 101 | 100 | 101 | high |
| 130 | 76.0% | 121 | 105 | 106 | 108 | 108 | 108 | high |
| 142 | 90.0% | 134 | 115 | 115 | 118 | 117 | 117 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## FloatTS Angelic Easy Larger -> beanTS Larger

Source leaderboard: 135509
Target leaderboard: 129353
Overlapping players: 42547 (98.7%)
Correlation: 0.9466
Log correlation: n/a
Linear regression: target ~= 1.3150 * source + -10.95 (R^2 0.8960)
Trimmed regression: target ~= 1.3388 * source + -13.25 (R^2 0.9317, n=40420)
Log-log regression: log(target) ~= 1.0833 * log(source) + -0.2001 (R^2 0.8825, n=42543)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 98 | 50% | 117 | high |
| 101.70 | 60% | 122 | high |
| 107 | 75% | 130 | high |
| 112.10 | 88% | 142 | high |
| 115.95 | 95% | 145 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 65 | 1.9% | 73 | 79 | 85 | 75 | 74 | 75 | high |
| 74 | 6.9% | 84 | 87 | 87 | 86 | 86 | 87 | high |
| 81 | 14.6% | 94 | 96 | 96 | 96 | 95 | 96 | high |
| 88 | 26.5% | 103 | 105 | 105 | 105 | 105 | 105 | high |
| 95 | 43.3% | 113 | 114 | 114 | 114 | 114 | 114 | high |
| 101 | 59.1% | 121 | 122 | 122 | 122 | 122 | 121 | high |
| 106 | 73.1% | 128 | 130 | 129 | 128 | 129 | 128 | high |
| 111 | 83.8% | 136 | 140 | 140 | 135 | 135 | 135 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## waldoTS Novice -> 1w2ts reload smallflicks larger

Source leaderboard: 113019
Target leaderboard: 185518
Overlapping players: 746 (1.5%)
Correlation: 0.8153
Log correlation: 0.7891
Linear regression: target ~= 0.7991 * source + 14.60 (R^2 0.6647)
Trimmed regression: target ~= 0.8183 * source + 11.53 (R^2 0.7444, n=709)
Log-log regression: log(target) ~= 0.8100 * log(source) + 0.8333 (R^2 0.6227, n=746)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 141.59 | 50% | 124 | high |
| 143.80 | 60% | 129 | high |
| 149.59 | 75% | 137 | high |
| 159.59 | 88% | 147 | high |
| 168.90 | 95% | 159 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 65 | 0.3% | 73 | 94 | 100 | 67 | 65 | 68 | medium |
| 78 | 1.5% | 85 | 94 | 100 | 77 | 75 | 78 | medium |
| 90 | 5.3% | 95 | 96 | 100 | 87 | 85 | 88 | medium |
| 100 | 12.0% | 102 | 99 | 100 | 95 | 93 | 96 | medium |
| 110 | 23.3% | 111 | 100 | 100 | 103 | 102 | 104 | medium |
| 120 | 41.0% | 120 | 108 | 109 | 110 | 110 | 111 | medium |
| 130 | 60.1% | 129 | 115 | 116 | 118 | 118 | 119 | medium |
| 140 | 76.4% | 138 | 124 | 124 | 126 | 126 | 126 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## devTS Goated NR Static 5Bot -> eth Pasu Micro Easier

Source leaderboard: 125002
Target leaderboard: 185394
Overlapping players: 634 (1.2%)
Correlation: 0.7810
Log correlation: 0.7702
Linear regression: target ~= 1.9163 * source + -258.69 (R^2 0.6100)
Trimmed regression: target ~= 1.9317 * source + -274.22 (R^2 0.6953, n=603)
Log-log regression: log(target) ~= 1.1840 * log(source) + -0.7744 (R^2 0.5932, n=634)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 750 | 50% | 1162 | high |
| 768 | 60% | 1216 | high |
| 813 | 75% | 1298 | high |
| 848 | 88% | 1404 | high |
| 875 | 95% | 1528 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 350 | 0.1% | 428 | 882 | 917 | 412 | 402 | 474 | medium |
| 400 | 0.3% | 532 | 882 | 917 | 508 | 498 | 555 | medium |
| 450 | 0.9% | 648 | 882 | 917 | 604 | 595 | 639 | medium |
| 500 | 3.1% | 768 | 882 | 917 | 699 | 692 | 723 | medium |
| 550 | 8.0% | 868 | 902 | 917 | 795 | 788 | 810 | medium |
| 600 | 18.6% | 974 | 917 | 917 | 891 | 885 | 898 | medium |
| 640 | 30.8% | 1048 | 998 | 996 | 968 | 962 | 969 | medium |
| 680 | 46.1% | 1134 | 1068 | 1060 | 1044 | 1039 | 1041 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## 1wall5targets_pasu slow -> Air Pure Easier No UFO

Source leaderboard: 544
Target leaderboard: 185405
Overlapping players: 69 (4.9%)
Correlation: 0.5176
Log correlation: 0.5135
Linear regression: target ~= 0.1622 * source + 917.91 (R^2 0.2679)
Trimmed regression: target ~= 0.1491 * source + 920.32 (R^2 0.2812, n=66)
Log-log regression: log(target) ~= 0.0311 * log(source) + 6.6920 (R^2 0.2637, n=69)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 173 | 50% | 947 | medium |
| 177 | 60% | 947 | medium |
| 182 | 75% | 949 | medium |
| 191 | 88% | 950 | medium |
| 201 | 95% | 953 | medium |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 76 | 0.0% | 834 | 945 | 945 | 930 | 932 | 922 | medium |
| 88 | 0.0% | 834 | 945 | 945 | 932 | 933 | 926 | medium |
| 100 | 0.0% | 834 | 945 | 945 | 934 | 935 | 930 | medium |
| 110 | 0.0% | 834 | 945 | 945 | 936 | 937 | 933 | medium |
| 120 | 0.0% | 834 | 945 | 945 | 937 | 938 | 935 | medium |
| 130 | 0.0% | 834 | 945 | 945 | 939 | 940 | 938 | medium |
| 140 | 0.0% | 834 | 945 | 945 | 941 | 941 | 940 | medium |
| 150 | 0.0% | 834 | 945 | 945 | 942 | 943 | 942 | medium |

### Warnings

- Source leaderboard collection is partial: 1400/129782 scores stored.
- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## B180 Voltaic Easy 92% -> Air Voltaic Invincible 4 Easier

Source leaderboard: 12018
Target leaderboard: 185406
Overlapping players: 717 (1.7%)
Correlation: 0.7713
Log correlation: 0.7692
Linear regression: target ~= 31.4074 * source + 1482.26 (R^2 0.5950)
Trimmed regression: target ~= 32.1469 * source + 1424.66 (R^2 0.6737, n=682)
Log-log regression: log(target) ~= 0.5974 * log(source) + 5.6745 (R^2 0.5917, n=717)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 84 | 50% | 4072 | high |
| 87 | 60% | 4255 | high |
| 90 | 75% | 4505 | high |
| 96 | 88% | 4716 | high |
| 104 | 95% | 4939 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 26 | 1.4% | 2058 | 2831 | 3200 | 2299 | 2260 | 2040 | medium |
| 38 | 6.9% | 2851 | 2831 | 3200 | 2676 | 2646 | 2559 | medium |
| 50 | 19.9% | 3383 | 3119 | 3200 | 3053 | 3032 | 3015 | medium |
| 58 | 32.6% | 3692 | 3337 | 3296 | 3304 | 3289 | 3295 | medium |
| 65 | 46.2% | 3975 | 3491 | 3491 | 3524 | 3514 | 3527 | medium |
| 72 | 60.5% | 4235 | 3713 | 3801 | 3744 | 3739 | 3749 | medium |
| 78 | 72.7% | 4454 | 4075 | 3956 | 3932 | 3932 | 3933 | medium |
| 87 | 86.1% | 4691 | 4546 | 4546 | 4215 | 4221 | 4198 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Controlsphere Click Easy -> Pasu Voltaic Reload Easier

Source leaderboard: 89547
Target leaderboard: 185636
Overlapping players: 571 (1.4%)
Correlation: 0.7879
Log correlation: 0.6590
Linear regression: target ~= 1.2632 * source + 17.13 (R^2 0.6207)
Trimmed regression: target ~= 1.2805 * source + 15.90 (R^2 0.7118, n=543)
Log-log regression: log(target) ~= 0.7324 * log(source) + 1.5176 (R^2 0.4343, n=571)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 56 | 50% | 87 | high |
| 58 | 60% | 92 | high |
| 62 | 75% | 99 | high |
| 68 | 88% | 109 | high |
| 74 | 95% | 117 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 15 | 0.9% | 36 | 55 | 69 | 36 | 35 | 33 | medium |
| 21 | 3.1% | 51 | 55 | 69 | 44 | 43 | 42 | medium |
| 27 | 7.4% | 58 | 57 | 69 | 51 | 50 | 51 | medium |
| 33 | 15.5% | 67 | 61 | 69 | 59 | 58 | 59 | medium |
| 39 | 27.8% | 75 | 70 | 70 | 66 | 66 | 67 | medium |
| 45 | 43.8% | 84 | 74 | 75 | 74 | 74 | 74 | medium |
| 50 | 59.2% | 91 | 84 | 84 | 80 | 80 | 80 | medium |
| 55 | 73.3% | 97 | 90 | 90 | 87 | 86 | 86 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Popcorn MV Novice -> 1w3ts Pasu Perfected Micro Goated Larger 80%

Source leaderboard: 76965
Target leaderboard: 128920
Overlapping players: 39313 (94.5%)
Correlation: 0.8033
Log correlation: n/a
Linear regression: target ~= 1.7697 * source + 607.83 (R^2 0.6453)
Trimmed regression: target ~= 1.7925 * source + 601.41 (R^2 0.7180, n=37348)
Log-log regression: log(target) ~= 0.3794 * log(source) + 4.8746 (R^2 0.6170, n=39305)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 270 | 50% | 1086 | high |
| 290 | 60% | 1134 | high |
| 330 | 75% | 1226 | high |
| 370 | 88% | 1322 | high |
| 410 | 95% | 1384 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 50 | 0.9% | 552 | 736 | 832 | 696 | 691 | 578 | high |
| 100 | 4.9% | 718 | 806 | 832 | 785 | 781 | 751 | high |
| 150 | 14.2% | 844 | 910 | 888 | 873 | 870 | 876 | high |
| 190 | 25.1% | 932 | 1016 | 981 | 944 | 942 | 958 | high |
| 230 | 38.9% | 1018 | 1056 | 1056 | 1015 | 1014 | 1030 | high |
| 270 | 53.5% | 1100 | 1122 | 1122 | 1086 | 1085 | 1095 | high |
| 300 | 64.7% | 1154 | 1174 | 1174 | 1139 | 1139 | 1140 | high |
| 330 | 76.0% | 1230 | 1238 | 1270 | 1192 | 1193 | 1182 | high |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Pasu Angelic 20% Larger 80% Speed -> Popcorn MV Easier

Source leaderboard: 129352
Target leaderboard: 185398
Overlapping players: 511 (1.2%)
Correlation: 0.7810
Log correlation: 0.7926
Linear regression: target ~= 5.5139 * source + -109.62 (R^2 0.6100)
Trimmed regression: target ~= 5.8086 * source + -139.81 (R^2 0.7028, n=486)
Log-log regression: log(target) ~= 1.3145 * log(source) + 0.0183 (R^2 0.6282, n=511)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 93 | 50% | 390 | high |
| 98 | 60% | 420 | high |
| 101 | 75% | 470 | high |
| 106 | 88% | 520 | high |
| 116 | 95% | 580 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 51 | 6.8% | 210 | 180 | 260 | 172 | 156 | 179 | medium |
| 58 | 13.5% | 260 | 240 | 260 | 210 | 197 | 212 | medium |
| 65 | 23.5% | 300 | 270 | 260 | 249 | 238 | 246 | medium |
| 72 | 36.2% | 340 | 275 | 270 | 287 | 278 | 281 | medium |
| 78 | 49.1% | 380 | 315 | 297 | 320 | 313 | 313 | medium |
| 84 | 62.3% | 420 | 370 | 353 | 354 | 348 | 345 | medium |
| 90 | 74.9% | 470 | 380 | 370 | 387 | 383 | 377 | medium |
| 97 | 85.6% | 510 | 480 | 480 | 425 | 424 | 416 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## 1w2ts Pasu Perfected Easy -> skyClick Goated Easier

Source leaderboard: 57757
Target leaderboard: 185490
Overlapping players: 535 (1.1%)
Correlation: 0.8673
Log correlation: 0.8742
Linear regression: target ~= 1.2171 * source + -15.14 (R^2 0.7522)
Trimmed regression: target ~= 1.2388 * source + -17.54 (R^2 0.8114, n=509)
Log-log regression: log(target) ~= 1.1193 * log(source) + -0.4900 (R^2 0.7643, n=535)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 106 | 50% | 112 | high |
| 110 | 60% | 115 | high |
| 112 | 75% | 124 | high |
| 118 | 88% | 135 | high |
| 125 | 95% | 149 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 58 | 1.3% | 65 | 76 | 86 | 55 | 54 | 58 | medium |
| 69 | 5.8% | 77 | 79 | 86 | 69 | 68 | 70 | medium |
| 80 | 19.4% | 93 | 86 | 86 | 82 | 82 | 83 | medium |
| 87 | 34.0% | 101 | 87 | 89 | 91 | 90 | 91 | medium |
| 93 | 49.3% | 110 | 97 | 98 | 98 | 98 | 98 | medium |
| 99 | 64.6% | 117 | 108 | 107 | 105 | 105 | 105 | medium |
| 105 | 78.1% | 125 | 112 | 111 | 113 | 113 | 112 | medium |
| 110 | 87.0% | 134 | 125 | 127 | 119 | 119 | 118 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## domiSwitch Easy Slower -> domiSwitch Easier

Source leaderboard: 128818
Target leaderboard: 185428
Overlapping players: 600 (1.4%)
Correlation: 0.8607
Log correlation: 0.8632
Linear regression: target ~= 0.8950 * source + 1555.60 (R^2 0.7408)
Trimmed regression: target ~= 0.9049 * source + 1479.69 (R^2 0.8096, n=570)
Log-log regression: log(target) ~= 0.7514 * log(source) + 2.3067 (R^2 0.7451, n=600)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 6368 | 50% | 7142 | high |
| 6472.80 | 60% | 7367 | high |
| 6692 | 75% | 7780 | high |
| 7149.60 | 88% | 8285 | high |
| 7788 | 95% | 8850 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 3200 | 2.4% | 4872 | 5340 | 5806 | 4419 | 4375 | 4322 | medium |
| 3700 | 5.1% | 5309 | 5387 | 5806 | 4867 | 4828 | 4820 | medium |
| 4200 | 10.5% | 5787 | 5719 | 5806 | 5314 | 5280 | 5301 | medium |
| 4600 | 18.0% | 6195 | 5806 | 5806 | 5672 | 5642 | 5676 | medium |
| 5000 | 28.7% | 6560 | 5925 | 6027 | 6030 | 6004 | 6043 | medium |
| 5400 | 42.8% | 6957 | 6354 | 6334 | 6388 | 6366 | 6403 | medium |
| 5800 | 58.9% | 7270 | 6567 | 6557 | 6746 | 6728 | 6757 | medium |
| 6300 | 75.1% | 7726 | 7377 | 7342 | 7194 | 7181 | 7190 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## tamTargetSwitch Smooth Easy -> kinTS Voltaic Easy 85%

Source leaderboard: 42505
Target leaderboard: 185408
Overlapping players: 627 (1.1%)
Correlation: 0.8211
Log correlation: 0.7936
Linear regression: target ~= 1.1605 * source + 32.86 (R^2 0.6742)
Trimmed regression: target ~= 1.1608 * source + 32.59 (R^2 0.7252, n=596)
Log-log regression: log(target) ~= 0.4126 * log(source) + 2.8151 (R^2 0.6297, n=627)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 30 | 50% | 68 | high |
| 32 | 60% | 70 | high |
| 35 | 75% | 74 | high |
| 37 | 88% | 79 | high |
| 41 | 95% | 84 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 7 | 3.4% | 48 | 52 | 56 | 41 | 41 | 37 | medium |
| 11 | 7.9% | 52 | 52 | 56 | 46 | 45 | 45 | medium |
| 15 | 15.0% | 57 | 52 | 56 | 50 | 50 | 51 | medium |
| 18 | 22.8% | 60 | 56 | 56 | 54 | 53 | 55 | medium |
| 21 | 33.1% | 63 | 61 | 60 | 57 | 57 | 59 | medium |
| 24 | 46.1% | 66 | 63 | 61 | 61 | 60 | 62 | medium |
| 26 | 55.7% | 68 | 65 | 65 | 63 | 63 | 64 | medium |
| 28 | 66.2% | 71 | 67 | 67 | 65 | 65 | 66 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## 1w3ts Pasu Perfected Micro Goated Larger 80% -> VoxTS Click Easier

Source leaderboard: 128920
Target leaderboard: 136076
Overlapping players: 603 (1.4%)
Correlation: 0.8900
Log correlation: 0.8874
Linear regression: target ~= 0.0751 * source + 4.95 (R^2 0.7922)
Trimmed regression: target ~= 0.0761 * source + 3.89 (R^2 0.8357, n=573)
Log-log regression: log(target) ~= 0.9427 * log(source) + -2.1320 (R^2 0.7875, n=603)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 1234 | 50% | 97 | high |
| 1302 | 60% | 101 | high |
| 1352 | 75% | 107 | high |
| 1446 | 88% | 117 | high |
| 1558 | 95% | 129 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 600 | 1.4% | 51 | 62 | 67 | 50 | 50 | 49 | medium |
| 700 | 4.1% | 62 | 62 | 67 | 58 | 57 | 57 | medium |
| 800 | 10.2% | 72 | 67 | 67 | 65 | 65 | 65 | medium |
| 900 | 20.5% | 81 | 76 | 75 | 73 | 72 | 72 | medium |
| 1000 | 35.7% | 89 | 79 | 81 | 80 | 80 | 80 | medium |
| 1100 | 53.5% | 98 | 90 | 89 | 88 | 88 | 87 | medium |
| 1200 | 71.5% | 105 | 97 | 96 | 95 | 95 | 95 | medium |
| 1300 | 83.4% | 113 | 102 | 102 | 103 | 103 | 102 | medium |

### Warnings

- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## Floating Heads Timing 400% Larger -> VT Floating Heads Viscose Easier

Source leaderboard: 1607
Target leaderboard: 185409
Overlapping players: 523 (1.1%)
Correlation: 0.8295
Log correlation: 0.8127
Linear regression: target ~= 0.2776 * source + -73.43 (R^2 0.6880)
Trimmed regression: target ~= 0.2779 * source + -75.72 (R^2 0.7488, n=497)
Log-log regression: log(target) ~= 1.0586 * log(source) + -1.8490 (R^2 0.6605, n=523)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 3240 | 50% | 815 | high |
| 3384 | 60% | 848 | high |
| 3600 | 75% | 943 | high |
| 3960 | 88% | 1056 | high |
| 4248 | 95% | 1180 | high |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 400 | 0.0% | 256 | 627 | 611 | 38 | 35 | 89 | medium |
| 700 | 0.0% | 256 | 627 | 611 | 121 | 119 | 162 | medium |
| 1000 | 0.0% | 256 | 627 | 611 | 204 | 202 | 236 | medium |
| 1350 | 0.0% | 256 | 627 | 611 | 301 | 299 | 324 | medium |
| 1700 | 0.0% | 256 | 627 | 611 | 399 | 397 | 414 | medium |
| 2050 | 0.0% | 256 | 627 | 611 | 496 | 494 | 505 | medium |
| 2400 | 11.1% | 579 | 611 | 611 | 593 | 591 | 596 | medium |
| 2750 | 34.9% | 733 | 734 | 734 | 690 | 689 | 689 | medium |

### Warnings

- Source leaderboard collection is partial: 47298/51395 scores stored.
- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.

## voxTargetSwitch Click -> VoxTS Click Easier

Source leaderboard: 653
Target leaderboard: 136076
Overlapping players: 217 (2.8%)
Correlation: 0.6908
Log correlation: 0.6720
Linear regression: target ~= 1.2470 * source + -18.53 (R^2 0.4772)
Trimmed regression: target ~= 1.3086 * source + -25.43 (R^2 0.5583, n=207)
Log-log regression: log(target) ~= 1.1963 * log(source) + -0.8500 (R^2 0.4515, n=217)

### Percentile Mapping

| Source score | Source percentile | Equivalent target score | Confidence |
| ---: | ---: | ---: | :--- |
| 103 | 50% | 112 | medium |
| 104 | 60% | 115 | medium |
| 107 | 75% | 121 | medium |
| 112 | 88% | 131 | medium |
| 124 | 95% | 137 | medium |

### Configured Cutoffs

| Source cutoff | Source percentile | Global target | Paired target | Monotonic target | Linear target | Trimmed target | Log target | Confidence |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| 49 | 0.0% | 35 | 115 | 115 | 43 | 39 | 45 | medium |
| 59 | 0.0% | 35 | 115 | 115 | 55 | 52 | 56 | medium |
| 67 | 0.0% | 35 | 115 | 115 | 65 | 62 | 65 | medium |
| 74 | 0.0% | 35 | 115 | 115 | 74 | 71 | 74 | medium |
| 81 | 0.0% | 35 | 115 | 115 | 82 | 81 | 82 | medium |
| 88 | 0.0% | 35 | 115 | 115 | 91 | 90 | 91 | medium |
| 94 | 0.0% | 35 | 115 | 115 | 99 | 98 | 98 | medium |
| 100 | 21.9% | 82 | 115 | 115 | 106 | 105 | 106 | medium |

### Warnings

- Source leaderboard collection is partial: 7800/80784 scores stored.
- Percentile mapping is restricted to overlapping players only.
- Trimmed regression excludes the largest 5% residual outliers from the initial linear model.
